package pack;
import java.io.*;
import java.util.ArrayList;

import eduni.simjava.Sim_entity;
import eduni.simjava.Sim_system;


public class Sim_main {
	
	public static void main(String[] args) throws IOException, InterruptedException {
	//	File f = new File("Results");
		Sim_system.initialise();
		Sim_system.set_trace_detail(false, true, false);
	
        Create_Ent ce = new Create_Ent("Create_Entities");
        
        Sim_system.set_output_analysis(Sim_system.IND_REPLICATIONS, 30, 0.95);
		Sim_system.run();

	}

}
