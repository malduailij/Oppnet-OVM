package pack;

public class Regular_Helper extends Helper{

	public Regular_Helper(String name, Parameters p, double msgPayloadReadTime) {
		super(name, p, msgPayloadReadTime);
		this.msgPayloadReadtime = msgPayloadReadTime;


	}

	
}
