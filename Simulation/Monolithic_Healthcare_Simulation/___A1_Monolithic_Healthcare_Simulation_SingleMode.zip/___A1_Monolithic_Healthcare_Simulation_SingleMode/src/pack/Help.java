package pack;

public class Help {

	String helpTextMsg = "Help 4351 Drake Rd 49009 Mi USA";
	String personProfile = "Name: Steve Thomas David, Age: 56 years old, Weight: 170 lbs., Allergies: Fever, asthma, eczema, hives, peanuts, Medications: Diabetes, Headache";
	String personContacts = "Primary Healthcare: Bronson, http://www.Bronson.com/DBServer, username: DavidSteve, password: 12345678";
	String personVitals = "Time: 08-20-2014-16:00:00, Temprature: 90, Blood preassure: 150/70";
}
